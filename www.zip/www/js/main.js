var vid = document.getElementById("myaudio");

vid.play();
